My further improvement for calculateEM()
1. Use editDistance to give em probability
2. Find silent letters, if there is silent letter then increase the em.
3. find similar letters such as k & q, s & c, j & g.